#!/usr/bin/env python3
"""Tests for cockpit_feed.py's pure parts (no Stump needed):
    python3 handheld/test_cockpit_feed.py
The whole path (feed + engine + a real stock Stump, chained) was tested by
running them together; see handheld/README.md "How it was tested"."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cockpit_feed as F  # noqa: E402


class ScreenLine(unittest.TestCase):
    def test_with_the_font_text_stays_as_sent(self):
        self.assertIsNotNone(F.font_chars())                 # cockpit_font.bin is next to the feed
        self.assertEqual(F.screen_line("\u2713 ~rod"), "\u2713 ~rod")
        self.assertEqual(F.screen_line("\u270e rod \u2192 bob"), "\u270e rod \u2192 bob")
        self.assertEqual(F.screen_line("caf\u00e9 \u00e0 Montr\u00e9al"), "caf\u00e9 \u00e0 Montr\u00e9al")
        self.assertEqual(F.screen_line("LaBuche_Cabin"), "LaBuche_Cabin")      # case kept

    def test_what_the_font_lacks_is_folded_or_dropped(self):
        self.assertEqual(F.screen_line("\u29d7 \u2014 slow"), "(slow down) \u2014 slow")
        self.assertEqual(F.screen_line("tree \U0001F332 \u0103"), "tree  a")

    def test_without_the_font_ascii_and_words(self):
        old = list(F._FONT_CHARS)
        F._FONT_CHARS[:] = [None]
        try:
            self.assertEqual(F.screen_line("\u2713 rod"), "+ rod joined")
            self.assertEqual(F.screen_line("\u2717 ~rod"), "- rod left")
            self.assertEqual(F.screen_line("caf\u00e9"), "cafe")
        finally:
            F._FONT_CHARS[:] = old

    def test_clip_cuts_between_characters(self):
        self.assertEqual(F.clip("\u00e9t\u00e9", 4), "\u00e9t")
        self.assertEqual(F.clip("abc", 45), "abc")


class Fields(unittest.TestCase):
    def test_clean_never_breaks_the_line_format(self):
        self.assertEqual(F.clean("a|b\nc\td", 60), "a/b c d")
        self.assertEqual(len(F.clean("x" * 100, 44)), 44)

    def test_nmcli_terse_split(self):
        self.assertEqual(F._split_nm(r"*:72:WPA2:Bob\:s net"), ["*", "72", "WPA2", "Bob:s net"])
        self.assertEqual(F._split_nm("wlan0:wifi:connected:Stump-Hotspot"),
                         ["wlan0", "wifi", "connected", "Stump-Hotspot"])


class Config(unittest.TestCase):
    def test_read_as_data_never_executed(self):
        d = tempfile.mkdtemp()
        with open(os.path.join(d, "config.py"), "w") as f:
            f.write("import os\nNODE_NAME = 'R36'\nPC_STORAGE_MB = 4096\n"
                    "AUTH_ADMIN_PASSWORD = 'pw'\nX = os.system('touch %s/ran')\n" % d)
        old, F.STUMP_DIR = F.STUMP_DIR, d
        try:
            cfg = F.read_config()
        finally:
            F.STUMP_DIR = old
        self.assertEqual((cfg["NODE_NAME"], cfg["PC_STORAGE_MB"]), ("R36", 4096))
        self.assertNotIn("X", cfg)
        self.assertFalse(os.path.exists(os.path.join(d, "ran")))


class Live(unittest.TestCase):
    def test_live_lines_match_the_engine_parser(self):
        feed = F.Feed()
        feed.node = {"lxmf": "ab" * 16, "release": "1.0.0-beta.42", "ap_ip": "10.42.0.1"}
        feed.stump.port = 80
        feed.chain = {"enabled": True, "role": "member", "secret": True, "chain": "d2a0d48a8da3",
                      "uplink": {"parent": "192.168.0.173", "parent_heard_s": 3}, "below": []}
        feed.msgs["wifi-mesh"] = [{"id": 1, "kind": "system", "nick": "*", "body": "✓ rod"},
                                  {"id": 2, "kind": "msg", "nick": "rod@LaBuche3", "body": "hi | there"}]
        feed.board = [{"id": "1793456586.959009450", "title": "Potluck", "body": "", "sig": "647c"}]
        feed.files = [{"name": "a, b.txt", "size": 3000, "cat": "document", "mtime": 1}]
        lines = feed.live_lines()
        get = lambda k: [l for l in lines if l.startswith(k + "|")]
        self.assertEqual(get("VER")[0].split("|")[3:6], ["1", "0", "10.42.0.1"])
        chain = get("CHAIN")[0].split("|")
        self.assertEqual(len(chain), 9)
        self.assertEqual(chain[1:4], ["1", "2", "1"])
        self.assertNotIn("secret", chain[4])                       # the secret itself is never shown
        self.assertIn("MSG|2|1|*|\u2713 rod", lines)
        self.assertIn("MSG|2|0|rod@LaBuche3|hi / there", lines)
        self.assertEqual(get("FILE")[0], "FILE|a_ b.txt|2|DOC")
        self.assertEqual(feed.full_names["a_ b.txt"], "a, b.txt")  # deletes reach the real name
        chars = F.font_chars()
        for l in lines:
            self.assertTrue(all(c in chars or c == "|" for c in l), l)   # only what the font can draw

    def test_ssids_shown_map_back_to_the_real_name(self):
        feed = F.Feed()
        feed.net["ssids"] = [{"active": True, "signal": 70, "sec": "WPA2", "ssid": "Caf\u00e9 \U0001F332 Guest|5G"}]
        line = [l for l in feed.live_lines() if l.startswith("SSID|")][0]
        shown = line.split("|", 4)[4]
        self.assertEqual(feed.full_ssids[shown], "Caf\u00e9 \U0001F332 Guest|5G")


if __name__ == "__main__":
    unittest.main(verbosity=1)
