# R36MAX Stump: changes

Each release is a git tag `v<VERSION>` (the version is in `handheld/VERSION`).
From 2.5.0 the version ends in `-b.NN`: the SandBox_Stump_On build
(1.0.0-beta.NN) it was tested against, as FireFly shows its build.
Pushing the tag runs the tests and publishes a GitHub release with
`R36MAX-Stump-handheld-<VERSION>.tar.gz`, its `SHA256SUMS`, and the section
below as its notes.

## v2.5.4-b.86

Tested against SandBox_Stump_On **1.0.0-beta.86** (the cockpit's feed with a
real b86 Stump: all pass; the RK3326 Provisioner's answers through b86's own
wizard: all pass).

- **Its announce stamps** (beta.86, Reticulum 1.6.1's proof of work on
  announces). With *Announce stamps* ticked in its /admin, the handheld's
  Stump finds them by itself in the background; the end of an install now
  also names Team Stump's tool to do it at once, every core on it:
  `provisioner.py --stamp-announces ~/Stump`. The RK3326 Provisioner
  (0.3.0-beta.20) does it from its screen.
- Nothing else needed changing for b83 to b86: the cockpit reads the Stump
  over its HTTP API, which stamps (on announces over the mesh) don't touch.

## v2.5.3-b.82

Tested against SandBox_Stump_On **1.0.0-beta.82** (the cockpit's feed with a
real b82 Stump: all pass; the RK3326 Provisioner's answers through b82's own
wizard: all pass).

- **Its packs and its identity, from Team Stump's own tools.** The end of an
  install says how, when its SandBox_Stump_On has them: `provisioner.py
  --packs ~/Stump` (beta.75: install, update, remove, nothing else asked)
  and `--save-identity ~/Stump` (beta.76: the file that brings back the same
  Stump on the mesh after a fresh install, with `--restore-identity`). The
  RK3326 Provisioner (0.3.0-beta.19) does both from its screen.
- Nothing else needed changing for b63 to b82: the cockpit reads the Stump
  over its HTTP API, which packed text (b82, LXMF over LoRa) doesn't touch.

## v2.5.2-b.62

Tested against SandBox_Stump_On **1.0.0-beta.62** (the cockpit's feed with a
real b62 Stump: all pass).

- **Installed from the RK3326 Provisioner, sudo's password typed on its
  screen.** With `--answers` (how the Provisioner runs it) install.sh
  needed sudo with no password at all, and stopped otherwise. Given sudo's
  askpass helper (the Provisioner 0.3.0-beta.16 passes one), every sudo in
  it goes through the helper (`sudo -A`), so a 10-20 minute first install
  outliving sudo's ticket still gets the password; a wrong one stops it
  before anything changes. Never piped into `sudo -S`. Over SSH nothing
  changes.

## v2.5.1-b.60

Tested against SandBox_Stump_On **1.0.0-beta.60**: the cockpit's feed with a
real b60 Stump (every command, the live file, the TF card: all pass), and the
answers the RK3326 Provisioner sends (0.3.0-beta.14) through b60's own wizard.

- **b58's setup questions.** The wizard asks the admin password (/admin;
  required) and gives the fserv bot the same one; its template has no
  passwords of its own any more. `install.sh --answers` takes the
  Provisioner's answers as they are (it sends b58's keys beside the old
  ones), and the password step finds both set: nothing to clear. Over SSH,
  the hints say the admin password is asked and required. The repo's
  password handling stays for Stumps before b58.
- The install's check says *parent … not heard yet* right after the start
  (it said "heard Nones ago"), and no longer prints the beta.43 reminder
  about the other Stumps every time (the warning about this one stays).
- Tests: `test_admin_password.py` with b58+'s template (no repo password:
  the older case kept with the template as it was), and as the wizard now
  writes both.

## v2.5.0-b.55

(`-b.55`: tested against SandBox_Stump_On 1.0.0-beta.55. v2.5.0-r36max was
tagged first by mistake and is the same code; this tag replaces it.)

**Nothing in the background: the Stump runs while its Port is open**, like a
ROM. Opening *Ports → LaBuche_Stump* starts the stock Stump and the cockpit;
SELECT+START stops both (the radio off first, through `/admin/poweroff` as
`stop-stump.sh` does) and goes back to EmulationStation. Checked against
SandBox_Stump_On **1.0.0-beta.55**.

- Why now: since 1.0.0-beta.55 a computer Stump speaks Reticulum's
  AutoInterface (Wi-Fi local discovery), the same one FireFly uses. On one
  handheld both can't: they want the same port on the same link-local
  address, and the first one up keeps it. With one Port at a time in
  EmulationStation, they never run together.
- `install.sh`: no start-at-login, no boot service, no `loginctl
  enable-linger`. An earlier install's `stump-ark` system service and
  `systemd --user` service are disabled and removed, and a running copy
  stopped. With `--answers`, *start this stump automatically when you log
  in* is forced to no. The final check starts the Stump, reads `/node.json`
  and `/chain.json`, then stops it. The sudoers file no longer allows
  `systemctl` (nothing to restart).
- `LaBuche_Stump.sh`: stops any copy left from before (v2.4's start-at-login
  too), starts the Stump for the session, and stops it on exit.
- What changes for the user: no web pages, AP, chain link or LoRa relay once
  the cockpit is closed; a remembered AP comes back when the cockpit is open.
  Over SSH, `~/Stump/start-stump.sh` / `stop-stump.sh` still work by hand.
- SandBox_Stump_On's beta.49-55 need nothing else here: the handheld's Stump
  gets the address page with both QR codes, NomadNet browsing and hubs, the
  NomadNet and Simple packs (say yes to them in the wizard, or
  `install nomadnet` / `install simple` in the answers file) and opt-in LXMF
  stamps for free. The suite, including the live test against a stock
  beta.55 Stump, passes unchanged.

## v2.4.0-r36max

**Its password reaches /admin.** Team Stump's design is one password:
/admin takes the fserv operator password (which the computer wizard asks)
unless `AUTH_ADMIN_PASSWORD` is set. But the wizard leaves
`AUTH_ADMIN_PASSWORD` as SandBox_Stump_On's `final_firmware/config.py` has
it unless "Change any of those now?" is answered yes, and that file isn't
blank: the password asked never reached /admin (found on the bench).

- After the wizard, `install.sh` clears the repo's `AUTH_ADMIN_PASSWORD`
  when the fserv operator password is set, so /admin takes that one, with
  the Stump's own `settings.write_config` (what /admin uses;
  `config.py.bak` kept). Over SSH, with no password of its own yet, it asks
  one (hidden, twice) for both.
- A separate /admin password, if wanted, comes from the answers file's
  `_admin password`.
- It says which password /admin takes, and warns while either is still the
  repo's.
- `admin_password.py`: the state of either password, `one` (the fserv
  operator's, and /admin's through it), `clear`, `set`; never printed or
  put on a command line.
- Tests: `test_admin_password.py` (with SandBox_Stump_On's real
  `settings.py` and `config.py` when given).

## v2.3.0-r36max

**Installed and updated from the RK3326 Provisioner, with the gamepad.**

- `install.sh --answers FILE.json`: the same install or update, with no one
  at the keyboard. The file answers SandBox_Stump_On's own wizard
  (`provisioner.py --pc --answers`, 1.0.0-beta.48 or newer); nothing is read
  from the keyboard, sudo must not ask for a password (dArkOS's `ark`
  doesn't), and whatever would ask stops the install with its reason. The
  RK3326 Provisioner's *This handheld's Stump* writes the file from a form on
  the screen and runs this.
- Without `--answers`, nothing changes: the wizard asks over SSH as before.
- The first install still needs internet (packages, SandBox_Stump_On, the
  Stump's Python packages); the messages say so when it's missing.
- Tests: the options (`--answers`, a missing file, an unknown option).

## v2.2.0-r36max

**Every Wi-Fi card is a limb with a job** (SandBox_RK3326_Stump, docs/PLAN.md).
The cockpit lists every Wi-Fi card on the handheld, plugged in in any order,
and gives each one a job: EmulationStation's network (shown, chosen there),
the Stump's AP, or nothing.

- **An AP on any card that supports AP mode**, the one EmulationStation uses
  included (it asks first, and says the handheld leaves that network; turning
  the AP off gives the network back). The card is asked, not a list, so a
  future card qualifies by itself.
- **As many APs as cards**, each on its own range (10.42.0.1, 10.42.1.1…),
  channel (1, 6, 11) and name (`-2`, `-3`…), 5 GHz where the card has it.
  Every AP hands out its own address for DNS, so each gets the sign-in page.
- **Remember** (Y on a card): a remembered AP comes back by itself when the
  card is plugged in again, or at boot, cockpit open or not
  (NetworkManager's autoconnect, kept per card by its hardware address).
- **Plugged in?** The cockpit says so and offers the card a job.
- The NETWORK tab has one row per card (←/→ the job, A apply, Y remember);
  SETUP shows the result. The old "stage, then apply in SETUP" is gone.
- v2.0's single hotspot connection (`Stump-Hotspot`) is replaced by the
  card's own the first time an AP is set.
- Tests: `test_limbs.py`, with the R36MAX's own `iw` output, a fake `/sys`
  and a NetworkManager that keeps state (take-over and back, N APs, ranges,
  5 GHz, remember, hotplug in any order); every character the cockpit draws
  is checked against its font.

## v2.1.0-r36max

**The Wi-Fi is EmulationStation's.** The network and its password are
chosen in dArkOS's own Wi-Fi settings; the Stump uses whatever network the
handheld is on, and follows a change by itself.

- The cockpit shows the network the handheld is on (name, signal, address).
  It no longer scans, joins networks or takes a Wi-Fi password.
- The hotspot only goes on a Wi-Fi adapter that network isn't using (the
  RT3070 next to the internal one). With one adapter in use it says so and
  leaves the network alone: it used to replace it.
- Tests: the feed never joins or changes a network, never sends a password,
  and keeps the hotspot off EmulationStation's adapter.

## v2.0.0-r36max

**The R36MAX runs the stock PC Stump.** It is now a Stump like macOS1 or any
Linux laptop: SandBox_Stump_On's `pc/stump_pc.py`, set up by
`provisioner.py --pc`, unmodified. The handheld's screen and buttons are a
client of it.

- **The bridge is gone.** `run_stump_r36max.py` (161 KB) moved the node's web
  server behind its own proxy, ran its own DHCP/DNS and chain discovery, and
  patched the firmware at run time. The stock Stump does all of that itself.
- **The cockpit talks to the Stump like a browser does**, through its public
  HTTP API (`/rrc/poll`, `/rrc/send`, `/post`, `/upload`, `/admin` deletes,
  `/chain.json`). It no longer writes the Stump's files, and no longer accepts
  chat lines from anyone on the LAN over UDP :42420.
- **Starts from boot**, serves on port 80 and answers captive DNS on 53 (one
  capability on the Stump's own Python, not the system's), and opens the
  hotspot through NetworkManager.
- **FireFly's look**: Team FireFly's amber palette, its DejaVu Sans Mono font,
  its header, chat bubbles and hint bar.
- **FireFly's keyboard, with real upper and lower case**, for chat, Wi-Fi
  passwords and the chain secret: A types, B deletes, X space, Y shift, L/R
  change page (letters, symbols, accents), START sends or OKs, SELECT cancels.
- **A USB keyboard** works on the OTG port or a hub: Shift, Caps Lock, the
  usual symbols; on the chat tab, just start typing.
- **Fixed:** the black screen on dArkOS (the cockpit draws through the system
  SDL2 on KMSDRM); `visudo` and `usermod` missing from dArkOS's sudo path; the
  old `echo 0 | sudo -S tee …`, which gave the data to sudo as its password.
- **No longer done on every launch:** flushing the firewall, masking
  NetworkManager, killing the Stump.
- **Needs SandBox_Stump_On 1.0.0-beta.43 or newer on every Stump** for other
  Stumps to show up by name within seconds of a restart (`install.sh` warns
  when it's older). Tested against 1.0.0-beta.46.
- **Tests and releases:** `handheld/tests/run_tests.sh` (versions, scripts,
  feed, font, engine, keyboard, the web app's copy) and
  `handheld/tests/test_with_stump.py` (every cockpit command against a real
  Stump) run on every push; a `v…` tag packages and publishes the release.
