"""Foundations for LaBuche-Stump nodes.

Nothing here is required for normal LXMF messaging: a Stump node is just an
LXMF peer. This module adds what a client needs to understand one:

- beacon detection (the `stump.node` announce on the node's identity)
- a parser for Stump's line protocol (symbols, DMs, AUTH tokens)
- the `/auth` challenge answer, built from the standard Reticulum identity
- the nick cleaning rules a node applies to announced display names

Reference: CLIENT_QUICKSTART.md and COMMANDS.md from the Stump project.
"""
import re
import time

import RNS
import RNS.vendor.umsgpack as msgpack

BEACON_APP, BEACON_ASPECT = "stump", "node"
AUTH_WINDOW_S = 60              # fixed on the node
SINGLE_PACKET_LIMIT = 295       # LXMF opportunistic content limit (title + content + fields)

_NICK_OK = re.compile(r"[A-Za-z0-9\-_\[\]{}\\^`|]")


def clean_nick(name, maxlen=16):
    """What a Stump node will turn an announced display name into (before any numeric suffix)."""
    out = "".join(c if _NICK_OK.match(c) else "-" for c in (name or ""))
    return out[:maxlen] or "guest"


# ---------------------------------------------------------------- beacons
class BeaconHandler:
    """Registers with RNS.Transport; calls on_stump(lxmf_hash_hex, name, version)."""
    aspect_filter = f"{BEACON_APP}.{BEACON_ASPECT}"
    receive_path_responses = True

    def __init__(self, on_stump):
        self.on_stump = on_stump

    def received_announce(self, destination_hash, announced_identity, app_data):
        info = parse_beacon(app_data)
        if not info:
            return
        # Since Stump 1.0.0-beta.37 a beacon naming an LXMF address that isn't its own
        # identity's is forged (anyone could make someone else look like a Stump): ignore it.
        if announced_identity is not None and not beacon_matches(announced_identity, info[0]):
            return
        self.on_stump(*info)


def beacon_matches(identity, lxmf_hex):
    return RNS.Destination.hash(identity, "lxmf", "delivery").hex() == lxmf_hex


def parse_beacon(app_data):
    """["stump", version, node name, 16-byte LXMF hash] -> (lxmf_hex, name, version) or None."""
    try:
        data = msgpack.unpackb(app_data)
        if not isinstance(data, list) or len(data) < 4 or data[0] != "stump":
            return None
        lxmf_hash = data[3]
        if not isinstance(lxmf_hash, (bytes, bytearray)) or len(lxmf_hash) != 16:
            return None
        version = str(data[1])
        # Sixth item (1.0.0-beta.35+): what the Stump is, short keys, all optional and untrusted.
        caps = data[5] if len(data) > 5 and isinstance(data[5], dict) else {}
        rel = caps.get("r")
        if isinstance(rel, str) and 0 < len(rel) <= 32:
            version = rel
        return lxmf_hash.hex(), str(data[2])[:32], version
    except Exception:
        return None


def beacon_hash_for(identity):
    """Destination hash of a peer's Stump beacon. request_path() on it to ask 'are you a Stump?'."""
    return RNS.Destination.hash(identity, BEACON_APP, BEACON_ASPECT)


# ---------------------------------------------------------------- line protocol
_DM = re.compile(r"^\[DM\] <([^>]+)>: (.*)$", re.S)
_ROOM_MSG = re.compile(r"^<([^>]+)> (.*)$", re.S)
_ROOM_LIST = re.compile(r"^#(\S+) ·(\d+)\s*(\[([A-Za-z][\w-]*)\])?\s*(.*)$")

# Stump 1.0.0-beta.4 renamed #lxmf to #lora-mesh; older nodes still say lxmf.
ROOM_ALIASES = {"lxmf": "lora-mesh"}
# Titles a Stump reads as "this batch comes from another Stump" (1.0.0-beta.21+):
# a client must never send them, nor a line starting "[DM>".
STUMP_ONLY_TITLES = ("#lora-mesh", "#wifi-mesh", "#lxmf")


def room_name(name):
    name = (name or "").lstrip("#")
    return ROOM_ALIASES.get(name, name)


def safe_for_stump(text, title=""):
    """(text, title) a Stump can't take for another Stump's batch."""
    if title and title.strip().lower() in STUMP_ONLY_TITLES:
        title = ""
    if text.startswith("[DM>"):
        text = "\u200b" + text            # invisible, but no longer the inter-Stump DM form
    return text, title


# The billboard over LoRa (Stump 1.0.0-beta.38+): /board, /board <words|id>, /post <title> | <body>.
_NOTICE = re.compile(r"^#(\d{6,}) (.+)$")
_POSTED = re.compile(r"^✓ #(\d{6,})\s*$")

TOKEN_SEP = " — "   # replies a client acts on: "<token> — <sentence for people>"


def _token_reply(line):
    """'= #lxmf — …', '? /frob — …', '⊘ #vip minted — …': stable tokens, the same in
    every language. Match the token; the sentence is only shown to the user."""
    if line.startswith("⧗") and TOKEN_SEP in line:
        return {"kind": "too_fast", "text": line.partition(TOKEN_SEP)[2]}
    if TOKEN_SEP not in line or line[:2] not in ("= ", "? ", "⊘ "):
        return None
    token, _, sentence = line.partition(TOKEN_SEP)
    sym, _, args = token.partition(" ")
    args = args.split()
    if sym == "=" and args and args[0].startswith("#"):
        return {"kind": "already_in", "room": room_name(args[0]), "text": sentence}
    if sym == "?" and args:
        return {"kind": "unknown_command", "command": args[0], "text": sentence}
    if sym == "⊘" and len(args) >= 2 and args[0].startswith("#"):
        return {"kind": "refused", "room": room_name(args[0]), "tier": args[1], "text": sentence}
    return None


_STUMP_TITLES = ("#lora-mesh", "#wifi-mesh", "#lxmf", "#main")
_STUMP_KINDS = ("moved", "already_in", "refused", "auth_challenge", "auth_ok", "auth_fail", "posted")


def looks_like_stump(content, title=""):
    """Only a Stump sends these: a room batch titled with one of its rooms, the
    '→ #room' landing line, its reply tokens, the /auth challenge."""
    if title and title.strip().lower() in _STUMP_TITLES:
        return True
    for l in (content or "").split("\n")[:12]:
        if l.strip() and parse_line(l)["kind"] in _STUMP_KINDS:
            return True
    return False


def parse_line(line):
    """Classify one line from a Stump node. Returns a dict with at least 'kind'."""
    line = line.rstrip("\r")
    head, _, rest = line.partition(" ")
    if head in ("AUTH-CHALLENGE", "AUTH-OK", "AUTH-FAIL"):   # wire tokens, never translated
        return {"kind": head.lower().replace("-", "_"), "arg": rest.strip()}
    tok = _token_reply(line)
    if tok:
        return tok
    m = _DM.match(line)
    if m:
        item = {"kind": "dm", "author": m.group(1), "text": m.group(2)}
        if m.group(2).startswith("♪ "):          # a voice DM: '♪ 5.0 s', the audio is in the field
            item["voice"] = m.group(2)[2:].strip()
        return item
    m = _NOTICE.match(line)
    if m:                                          # /board answer: '#482193 Marché samedi'
        return {"kind": "notice", "id": m.group(1), "title": m.group(2)}
    m = _POSTED.match(line)
    if m:                                          # /post answer: '✓ #482193'
        return {"kind": "posted", "id": m.group(1)}
    if line.startswith("✓ "):
        return {"kind": "join", "nick": line[2:].strip()}
    if line.startswith("✗ "):
        return {"kind": "part", "nick": line[2:].strip()}
    if line.startswith("✎ "):
        body = line[2:]
        if body.startswith("#"):
            room, _, topic = body.partition(" ")
            return {"kind": "topic", "room": room_name(room), "topic": topic}
        old, _, new = body.partition(" → ")
        return {"kind": "rename", "old": old.strip(), "new": new.strip()}
    if line.startswith("→ #"):
        return {"kind": "moved", "room": room_name(line[3:].strip())}
    if line.startswith("⊖ "):
        return {"kind": "no_such_nick", "nick": line[2:].strip()}
    if line.startswith("* "):
        nick, _, text = line[2:].partition(" ")
        return {"kind": "action", "nick": nick, "text": text}
    m = _ROOM_LIST.match(line)
    if m:
        return {"kind": "room", "room": room_name(m.group(1)), "count": int(m.group(2)),
                "tier": m.group(4) or "open", "topic": m.group(5)}
    if line.startswith("#") and ": " in line:
        room, _, names = line.partition(": ")
        return {"kind": "names", "room": room_name(room), "names": [n.strip() for n in names.split(",") if n.strip()]}
    m = _ROOM_MSG.match(line)
    if m:
        return {"kind": "msg", "nick": m.group(1), "text": m.group(2)}
    return {"kind": "text", "text": line}


ROOM_KINDS = ("msg", "action", "join", "part", "rename")


def parse_message(content, title=""):
    """A Stump LXMF message may carry several lines, one item each.

    Pushed room batches name their room in the LXMF title ('#lxmf'): room
    lines are filed under that room, not under the room the client thinks it
    is in, because lines queued just before a /join may still arrive. DM-only
    batches have no title (each [DM] line names its author)."""
    room = room_name(title) if title and title.startswith("#") else None
    items = []
    for l in content.split("\n"):
        if not l.strip():
            continue
        item = parse_line(l)
        if room and item["kind"] in ROOM_KINDS:
            item["room"] = room
        items.append(item)
    return items


class NodeState:
    """What a client knows about its place on one Stump node."""

    def __init__(self):
        self.room = None          # where the node says we are
        self.refused = None       # last tier refusal: (room, tier, sentence)

    def update(self, items):
        for it in items:
            if it["kind"] in ("moved", "already_in"):
                self.room = it["room"]
            elif it["kind"] == "refused":
                self.refused = (it["room"], it["tier"], it["text"])


def is_mesh_nick(nick):
    """'~rod' marks a mesh user in room activity; the '~' is not part of the nick."""
    return nick.startswith("~")


# ---------------------------------------------------------------- /auth
def auth_answer(identity, nonce_hex):
    """'/auth <pubkey_hex> <sig_hex>' for a challenge.

    The public key is the standard Reticulum identity key: X25519 public (32)
    + Ed25519 public (32) = 128 hex chars. The signature is Ed25519 over the
    ASCII text of the nonce, NOT the bytes it decodes to.
    """
    nonce_hex = nonce_hex.strip()
    if not re.fullmatch(r"[0-9a-fA-F]{32}", nonce_hex):
        raise ValueError("challenge nonce must be 32 hex characters")
    pub = identity.get_public_key().hex()
    sig = identity.sign(nonce_hex.encode("ascii")).hex()
    return f"/auth {pub} {sig}"


class AuthSession:
    """One /auth handshake with one node. Only one may be in flight per node,
    because a second /auth silently replaces the pending challenge."""
    IDLE, WAITING_CHALLENGE, WAITING_RESULT, OK, FAILED = range(5)

    def __init__(self, node_hash, max_restarts=2):
        self.node_hash = node_hash
        self.state = self.IDLE
        self.started = None
        self.challenge_at = None
        self.identity_hash = None
        self.reason = None
        self.restarts = 0
        self.max_restarts = max_restarts
        self.rtt = None           # seconds from /auth sent to challenge received

    @property
    def busy(self):
        return self.state in (self.WAITING_CHALLENGE, self.WAITING_RESULT)

    def start(self):
        self.state = self.WAITING_CHALLENGE
        self.started = time.time()
        self.reason = None
        return "/auth"

    def on_line(self, parsed, identity):
        """Feed a parsed line. Returns a message to send (or None)."""
        k = parsed["kind"]
        if k == "auth_challenge" and self.state == self.WAITING_CHALLENGE:
            self.challenge_at = time.time()
            self.rtt = self.challenge_at - self.started
            self.state = self.WAITING_RESULT
            return auth_answer(identity, parsed["arg"])
        if k == "auth_ok" and self.state == self.WAITING_RESULT:
            self.state = self.OK
            self.identity_hash = parsed["arg"]
            return None
        if k == "auth_fail" and self.busy:
            self.reason = parsed["arg"]
            if "expired" in self.reason and self.restarts < self.max_restarts:
                self.restarts += 1
                return self.start()           # every challenge is single-use: just start over
            self.state = self.FAILED
        return None
